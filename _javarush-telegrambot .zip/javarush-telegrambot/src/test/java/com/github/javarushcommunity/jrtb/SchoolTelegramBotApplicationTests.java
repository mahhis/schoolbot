package com.github.javarushcommunity.jrtb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolTelegramBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
